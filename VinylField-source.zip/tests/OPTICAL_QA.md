# Optical Editorial QA — 0.14.5

## Verified in headless Chromium
- Warm / blue albums at 1280×720; short landscape 850×393; portrait 390×844.
- Album artwork decodes; switching lyric focus preserves lyric readability and adds a large album-jacket presentation in wide landscape.
- Audio seek preview, cancellation and commit exercised using WAV media.
- Album color/pressing classification and 100-track queue regression tests passed.
- JavaScript page errors: none in the verified viewports.

## Not verified
- Android APK compilation or installation, Android WebView GPU performance, real Netease login, lyric/API availability, Bluetooth media controls.

## Rollback
- 0.14.4 remains untouched as the previous source checkpoint. The new visual layer is `optical-editorial.css`, loaded after `controls-refined.css`. Removing this stylesheet link restores the old optical treatment and folio layout.
