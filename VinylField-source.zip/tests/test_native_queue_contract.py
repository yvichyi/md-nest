from pathlib import Path
from playwright.sync_api import sync_playwright
import base64,re,json
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
html=(root/'index.html').read_text()
for name in ['style.css','cover-theme.css','immersive-motion.css','art-direction.css','motion-engine.css']:
    html=html.replace(f'<link rel="stylesheet" href="{name}" />', '<style>'+ (root/name).read_text() +'</style>')
for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
    mime='image/jpeg';url='data:'+mime+';base64,'+base64.b64encode((root/name).read_bytes()).decode()
    html=html.replace(name,url)
js=(root/'playback-clock.js').read_text()+'\n'+(root/'app.js').read_text()
assert '<script src="app.js"></script>' in html
mock='''<script>
window.__calls=[];
window.Vinyl={
 setChromeColour: (...args)=>window.__calls.push(['setChromeColour',...args]),
 playLocalQueue:(...args)=>window.__calls.push(['playLocalQueue',...args]),
 play:(...args)=>window.__calls.push(['play',...args]),
 setQueueMode:(...args)=>window.__calls.push(['setQueueMode',...args]),
 playQueueIndex:(...args)=>window.__calls.push(['playQueueIndex',...args]),
 next:()=>window.__calls.push(['next']),previous:()=>window.__calls.push(['previous']),
 seek:(...args)=>window.__calls.push(['seek',...args]),
 pause:()=>window.__calls.push(['pause']),resume:()=>window.__calls.push(['resume']),
 pickAudio:()=>window.__calls.push(['pickAudio']),
 landscape:()=>{},portrait:()=>{}
};
</script>'''
html=html.replace('<script src="playback-clock.js"></script>', '').replace('<script src="app.js"></script>',mock+'<script>'+js+'</script>')
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1280,'height':720})
    errs=[]
    page.on('pageerror',lambda e: errs.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded',timeout=30000)
    page.evaluate("window.VF.addLocalTrack('content://provider/audio/one','One.mp3')")
    page.evaluate("window.VF.addLocalTrack('content://provider/audio/two','Two.mp3')")
    calls=page.evaluate('window.__calls')
    local=[c for c in calls if c[0]=='playLocalQueue']
    assert len(local)==2,local
    t1=json.loads(local[0][1]);t2=json.loads(local[1][1])
    assert len(t1)==1 and len(t2)==2,(t1,t2)
    assert local[-1][2]==1 and local[-1][3]=='all'
    assert page.locator('#songTitle').inner_text()=='Two',page.locator('#songTitle').inner_text()
    media_id=t2[0]['id']
    page.evaluate('''s=>window.VF.onNativeState(s)''',{'hasItem':True,'playing':True,'position':1500,'duration':160000,'mediaIndex':0,'queueCount':2,'mediaId':media_id,'repeatMode':2,'shuffle':False})
    assert page.locator('#songTitle').inner_text()=='Two' # stale first-track report ignored
    # Confirm the requested item before testing headset navigation.
    page.evaluate('''s=>window.VF.onNativeState(s)''',{'hasItem':True,'playing':True,'position':0,'duration':200000,'mediaIndex':1,'queueCount':2,'mediaId':t2[1]['id'],'repeatMode':2,'shuffle':False})
    page.evaluate('''s=>window.VF.onNativeState(s)''',{'hasItem':True,'playing':True,'position':1500,'duration':160000,'mediaIndex':0,'queueCount':2,'mediaId':media_id,'repeatMode':2,'shuffle':False})
    assert page.locator('#songTitle').inner_text()=='One',page.locator('#songTitle').inner_text()
    page.locator('#nextBtn').click()
    assert page.evaluate('window.__calls.at(-1)[0]') == 'next',page.evaluate('window.__calls.slice(-5)')
    page.locator('#toolsToggle').click()
    page.locator('#shuffleBtn').click()
    assert page.evaluate('window.__calls.filter(c=>c[0]=="setQueueMode").at(-1)')==['setQueueMode','all',True]
    page.evaluate('''s=>window.VF.onNativeState(s)''',{'hasItem':True,'playing':True,'position':300,'duration':210000,'mediaIndex':1,'queueCount':2,'mediaId':t2[1]['id'],'repeatMode':2,'shuffle':True})
    assert page.locator('#songTitle').inner_text()=='Two'
    page.locator('#prevBtn').click()
    assert page.evaluate('window.__calls.at(-1)[0]') == 'previous',page.evaluate('window.__calls.slice(-5)')
    # Restore from a native session whose stored JS queue is stale.
    page.evaluate('''()=>window.VF.onNativeState({hasItem:true,playing:false,position:5,duration:10000,
      mediaId:'unknown-native',mediaIndex:0,queueCount:1,title:'Restored sound',artist:'Local author',uri:'content://provider/missing'})''')
    assert page.locator('#songTitle').inner_text()=='Restored sound'
    assert not errs,errs
    print('PASS native local queue transfer, state reconciliation, headset skip delegation, shuffle sync, orphan session recovery')
    print('calls:',len(calls), 'browser errors:',errs)
    browser.close()
