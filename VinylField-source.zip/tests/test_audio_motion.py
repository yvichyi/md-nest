from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
def bundled(kind=None,native=False):
    html=(root/'index.html').read_text()
    for name in ['ui-bundle.css']:
        html=html.replace(f'<link rel="stylesheet" href="{name}" />', '<style>'+ (root/name).read_text() +'</style>')
    for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
        html=html.replace(name,'data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode())
    clock=(root/'playback-clock.js').read_text()
    js=(root/'app.js').read_text()
    for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
        js=js.replace(name,'data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode())
    if kind:
        js=js.replace("const visualDemo = !native && new URLSearchParams(location.search).get('demo');",f"const visualDemo = '{kind}';")
    native_js='''window.Vinyl={setChromeColour(){},playLocalQueue(...args){window.__nativeQueue=args;},play(){},setQueueMode(){},playQueueIndex(){},next(){},previous(){},seek(){},pause(){},resume(){},pickAudio(){},landscape(){},portrait(){}};''' if native else ''
    html=html.replace('<script src="playback-clock.js"></script>','').replace('<script src="pressing-studio.js"></script>','').replace('<script src="app.js"></script>',f'<script>{native_js}\n{clock}\n{(root/"pressing-studio.js").read_text()}\n{js}</script>')
    return html

# Self-contained real audio fixture, rather than an old conversation artifact.
import wave, math, struct, tempfile
fixture=Path(tempfile.gettempdir())/'vinylfield-motion-fixture.wav'
with wave.open(str(fixture),'wb') as f:
  f.setnchannels(1);f.setsampwidth(2);f.setframerate(16000)
  f.writeframes(b''.join(struct.pack('<h',int(8000*math.sin(2*math.pi*220*i/16000))) for i in range(96000)))
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
  page=browser.new_page(viewport={'width':1280,'height':720})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(bundled(),wait_until='load')
  page.locator('#browserFile').set_input_files(str(fixture))
  page.wait_for_timeout(600)
  one=page.evaluate('window.VF.motionSnapshot()')
  assert one['position']>30 and one['velocity']>1,one
  page.locator('#playBtn').click()
  page.wait_for_timeout(500)
  two=page.evaluate('window.VF.motionSnapshot()')
  assert two['velocity']<one['velocity'],(one,two)
  page.wait_for_timeout(300)
  three=page.evaluate('window.VF.motionSnapshot()')
  assert abs(two['position']-three['position'])<45,(two,three)
  assert not errors,errors
  print('PASS real local WAV → playback position and rotation → pause inertia and frozen time',one,two,three)
  browser.close()
