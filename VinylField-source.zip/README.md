# VinylField 0.15.0 — Tangible Record

Android 8+ WebView interface backed by Media3 playback and a third-party Netease bridge.

## This release

- Hold the outer record groove for 290ms to enter angular song-position preview; rotate to locate, release to seek.
- Pointer cancel restores the existing play position; holding the label still opens the queue; swipe to skip, tap to play/pause.
- Stable nonrotating hit geometry, accessible conventional seek slider, 30px touch target, keyboard seek; respect reduced-motion settings.
- Record seek has its own compact readout, without a second generic scrub tooltip.
- Album-specific pressing and lyric folio remain unchanged.
- versionCode 150 / versionName 0.15.0.

## Verification

`python tests/test_tangible_record.py` exercises 4 screen/theme combinations using a REAL WAV with commit/cancel checks.
`python tests/test_interaction_refinement.py`, `node tests/test_playback_clock.cjs`, `python tests/test_native_queue_contract.py`, `python tests/test_queue_100.py`, `python tests/test_album_identity.py` and `python tests/test_pressing_studio.py` cover regressions.

## Limitations

Unlicensed content is not bypassed. Netease unofficial API access and QR account authorization are not guaranteed; real-device Bluetooth, notification behavior and GPU frame time require physical Android verification. This is a test/debug build, not a production-signed release.
