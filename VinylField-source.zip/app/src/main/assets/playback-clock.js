/* VinylField 0.11 — monotonic, testable position interpolation.
 * Media3/browser audio remains authoritative; this clock never commands playback.
 * It only smooths position between confirmed playback snapshots.
 */
(function (root, factory) {
  const Clock = factory();
  if (typeof module === 'object' && module.exports) module.exports = Clock;
  if (root) root.VFPlaybackClock = Clock;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const finite = (v, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
  const clamp = (v, low, high) => Math.max(low, Math.min(v, high));
  return class VFPlaybackClock {
    constructor() { this.reset(); }
    reset(position = 0, duration = 0, now = 0, mediaId = '') {
      this.anchorPosition = Math.max(0, finite(position));
      this.duration = Math.max(0, finite(duration));
      this.anchorTime = finite(now);
      this.playing = false;
      this.buffering = false;
      this.mediaId = String(mediaId || '');
      this.lastReason = 'reset';
    }
    sample(now) {
      const dt = Math.max(0, finite(now, this.anchorTime) - this.anchorTime);
      const p = this.anchorPosition + (this.playing && !this.buffering ? dt : 0);
      return this.duration > 0 ? clamp(p, 0, this.duration) : Math.max(0, p);
    }
    observe(snapshot, now, reason = 'periodic') {
      const time = finite(now, this.anchorTime);
      const position = Math.max(0, finite(snapshot.position, this.anchorPosition));
      const duration = Math.max(0, finite(snapshot.duration, this.duration));
      const playing = !!snapshot.playing;
      const buffering = !!snapshot.buffering;
      const mediaId = String(snapshot.mediaId ?? this.mediaId);
      const predicted = this.sample(time);
      const drift = position - predicted;
      const discontinuity = reason !== 'periodic' || (mediaId && this.mediaId && mediaId !== this.mediaId)
        || playing !== this.playing || buffering !== this.buffering || Math.abs(drift) > 550;
      // Small native/bridge timing fluctuations are eased instead of forcing visual jumps.
      this.anchorPosition = discontinuity ? position : predicted + clamp(drift * .18, -75, 75);
      this.duration = duration;
      this.anchorTime = time;
      this.playing = playing;
      this.buffering = buffering;
      this.mediaId = mediaId;
      this.lastReason = discontinuity ? 'snap' : 'corrected';
      return {position:this.sample(time), drift, snapped:discontinuity};
    }
  };
});
