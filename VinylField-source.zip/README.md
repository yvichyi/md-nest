# VinylField 0.10.1 — Native Transport Reliability

Third-party, unofficial Android music player with a cover-driven translucent-vinyl fullscreen UI. Inspired by the composition in a QQ Music landscape colour-vinyl screenshot; not affiliated with QQ Music or NetEase Cloud Music.

## 0.10.1 — real improvements

- The local `content://` playlist is now handed to Media3 as a complete native playlist; it no longer only sees one track.
- Android media controllers, headset transport and notification controls can navigate imported local tracks without WebView needing to remain active.
- Native Media3 reports current media ID/index; the page updates title, album, and lyrics when another controller changes track. It also recovers metadata if its saved queue is missing.
- Shuffle/repeat mode changes go to Media3 for native local playlists.
- Version updated to `versionCode 11` / `versionName 0.10.1`; UI edition footer updated.
- **Explicit limitation:** remote NetEase tracks remain individually resolved on demand. Signed stream URLs expire; native multi-track controls for cloud playlists are NOT yet implemented.
- Browser-native-bridge simulation checks can be rerun with `python tests/test_native_queue_contract.py` (requires Playwright + Chromium). Android/JVM compilation and device Bluetooth are separately verified, not inferred from browser checks.

## What actually changed from 0.9.0

- **Spatial composition**: 1280×720 disc diameter reduced from the approximately 799px CSS design size to 480px. Lyric stage and disc occupy dedicated space, rather than competing for the full screen.
- **Music drawer**: reworked from a flat screen-height sidebar into a floating, cover-derived light panel with segmented navigation, a functional search, useful search shortcuts, a NetEase account link and a local audio import entry. The shortcut destinations perform real UI actions; no fake track results are shown.
- **Tools menu**: 2×3 named action menu with visible labels and playback states, rather than a row of unidentified icons.
- **Gesture controls**: tap the disc to play/pause, swipe horizontally to skip, hold to open the queue, and tap a timestamped lyric to seek.
- **Lyric focus**: on-screen accessible toggle; also keyboard L. Keyboard Q opens queue; Space toggles playback; Left/Right seeks ±5 seconds; Shift+Left/Right changes track. Escape closes panels.
- **Motion**: continuous playback-driven disc rotation, inertia on pause, independent optical catch, pointer-following halo, modest playback-only light breathing. Reduced-motion OS preference disables nonessential animation.
- **Preservation**: kept NetEase bridge, cover-colour extraction, Media3 native playback service and QR/login data contracts unchanged.

## Verified (Chromium 128 / Playwright, synthetic fixture)

- 1280×720: disc rectangle (710,115) 480×480; side lyric bounds (92,228) 630×297; no page horizontal overflow.
- 850×393: disc 295×295, lyric and transport do not overlap; fixed a compact-layout label collision.
- 390×844: portrait disc 296×296; lyric/progress remain reachable.
- Warm and cool local test covers loaded successfully. JS console errors: none in the checked states.
- In a browser with a real local WAV: audio starts, CSS disc angle changes continuously, tapping the disc pauses audio, pressing Q opens the queue, Escape closes it, focus toggle works, swipe causes no JS exception, and holding opens the queue.
- Drawer: both actions visible in wide and phone screens; connect button opens the account overlay; search suggestion issues the corresponding query and hides the introductory state.

Source: `app/src/main/assets/index.html`, `art-direction.css`, `app.js`. The bundled preview HTML files are fully offline, with locally embedded demo covers and illustrative lyrics; they are not live NetEase proof.

## Known boundaries

- This source revision requires a new APK; do not install or distribute a previous APK under the 0.10.1 version label.
- No Android hardware performance / GPU profiling, QR-login flow or live NetEase catalogue validation in this round. Cover artwork and lyrics shown in the screenshots are bundled demonstration content.
- Prior CSS layers still provide some base widget styling. The final `art-direction.css` overrides their presentation: a future cleanup should unify the full stylesheet graph instead of adding another cumulative theme layer.

## Build

Requires Android SDK 35, JDK 17 and Gradle 8.11.1. From the project directory:

`gradle --no-daemon :app:assembleDebug`

The repository includes a GitHub Actions workflow for the Android build. Always inspect actual build status and APK before claiming success.


## 0.10.1 verification notes

- Playwright mock bridge: local playlist hand-off, native skip, shuffle synchronization, external media-ID update and orphan-session recovery passed.
- This test does not simulate real Media3, Bluetooth devices, QR login or third-party streaming.
