const assert = require('node:assert/strict');
const test = require('node:test');
const {mergeTranslations} = require('../app/src/main/assets/lyric-translations.js');
const original = [
  {time:1000,text:'Rain at the window'},
  {time:4000,text:'A quiet room'},
  {time:7000,text:'Time moves on'}
];
test('partial translations align by timestamp without shifting later verses', () => {
  const translated = [{time:1000,text:'窗边的雨'}, {time:7000,text:'时间向前'}];
  const result = mergeTranslations(original, translated);
  assert.deepEqual(result.map(line=>line.translation), ['窗边的雨','','时间向前']);
  assert.equal(original[0].translation, undefined);
});
test('small rounding differences match; distant or ambiguous lines do not', () => {
  assert.equal(mergeTranslations(original,[{time:1120,text:'窗边的雨'}])[0].translation,'窗边的雨');
  assert.equal(mergeTranslations(original,[{time:1800,text:'不应匹配'}])[0].translation,'');
  assert.equal(mergeTranslations(original,[{time:900,text:'左'},{time:1100,text:'右'}])[0].translation,'');
});
test('exact timestamps are reserved before approximate matches', () => {
  const result=mergeTranslations([{time:1000,text:'first'},{time:1100,text:'second'}],[{time:1100,text:'第二句'}]);
  assert.deepEqual(result.map(line=>line.translation),['','第二句']);
});
test('one translated timestamp is not reused for distinct nearby original rows', () => {
  const result=mergeTranslations([{time:1000,text:'first'},{time:1200,text:'second'}],[{time:1090,text:'一句'}]);
  assert.equal(result.filter(line=>line.translation).length,1);
});
test('a later original keeps the subtitle that is closer to it', () => {
  const rows=[{time:1000,text:'first'},{time:1200,text:'second'}];
  assert.deepEqual(mergeTranslations(rows,[{time:1190,text:'第二句'}]).map(line=>line.translation),['','第二句']);
  assert.deepEqual(mergeTranslations(rows,[{time:1100,text:'归属不明'}]).map(line=>line.translation),['','']);
});
test('repeated timestamps share subtitles and duplicate translated text is removed', () => {
  const result=mergeTranslations([{time:1000,text:'voice one'},{time:1000,text:'voice two'}],
    [{time:1000,text:'第一声'},{time:1000,text:'第一声'},{time:1000,text:'第二声'}]);
  assert.deepEqual(result.map(line=>line.translation),['第一声\n第二声','第一声\n第二声']);
});
test('missing, malformed, identical and literal markup translations are safe data', () => {
  assert.deepEqual(mergeTranslations(original,[]).map(line=>line.translation),['','','']);
  assert.equal(mergeTranslations(original,[{time:NaN,text:'invalid'}])[0].translation,'');
  assert.equal(mergeTranslations(original,[{time:1000,text:original[0].text}])[0].translation,'');
  assert.equal(mergeTranslations(original,[{time:1000,text:'<img src=x>'}])[0].translation,'<img src=x>');
});
