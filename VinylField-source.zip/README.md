# VinylField 0.13.0 — Pressed Light

Unofficial Android music player with full-screen, cover-driven coloured vinyl. Not affiliated with NetEase or QQ Music. Builds on the independently preserved 0.12.0 source.

## Changes in 0.13.0

- **Cover-derived digital pressing:** `pressing-studio.js` reads artwork pixels (local artwork or the verified NetEase-cover data URI returned by the Android bridge), groups tonal colour populations, selects two pigments, and creates a deterministic 320×320 texture with restrained grooves, radial material variation and directional reflection. A handful of finish classes (`clear`, `smoke`, `pearl`, `duotone`, `marble`) describe optical fabrication, not hard-coded per-song skins.
- **No frame-by-frame pixel synthesis:** texture is generated at artwork changes only, cached for 8 recent material signatures. The original CSS resin remains the fallback. Rotation still comes from the Media3-aligned playback clock implemented in 0.11.0.
- **Night-sky colour correction:** cool scene regions take priority over small warm highlights in dark covers. Palette is generated from the artwork, not an immutable app theme.
- **Generation guard:** artwork decode callbacks are ignored when a newer song has already started. Cached textures are stable across repeated playback of the same album.
- **Stylesheet pipeline:** production HTML loads one pinned-order `ui-bundle.css` built from seven readable source stylesheets using `python tools-bundle-css.py`. This removes order drift and extra runtime stylesheet requests, *not* all historical cascade overrides.
- **Version:** `versionName 0.13.0`, `versionCode 14`.

## Run checks

Python 3 and Playwright + Chromium are needed for browser checks; Gradle builds need Java 17 + Android SDK 35.

```sh
python tools-bundle-css.py
node tests/test_playback_clock.cjs
python tests/test_pressing_studio.py
python tests/test_queue_100.py
python tests/test_native_queue_contract.py
gradle --no-daemon :app:assembleDebug
```

Tests cover six synthetic cover styles, 3 viewports, deterministic output, separate lyric folio, queue drawer and 100-track list, Media3 bridge mock, playback clock and artwork changes. Demo art/lyrics are illustrative only; these tests do not validate streaming rights, NetEase QR authorization, native Bluetooth behavior or device GPU frame pacing.

The renderer intentionally does not claim photoreal vinyl optics or actual groove-to-audio mapping. Its production path does not use WebGL; material detail is pre-rendered to a static canvas texture and composited by the existing disc view. A device-performance/quality gate is required before considering real-time shaders.
