# VinylField 0.15.1 — Sleeve Edition

Android 8+ WebView interface backed by Media3 playback and a third-party Netease bridge.

## This release

- Based on `vinylfield-apk-build` commit `a19589e` (2026-10-10 22:01, Asia/Shanghai), whose packaged source is 0.15.0.
- Serif song titles, quieter album-derived paper, clearer lyric hierarchy and more restrained record highlights and shadows.
- Coordinated discovery, queue and account panels; 44px menu touch targets and readable two-line gesture hints in short landscape.
- Portrait lyric folio keeps the album jacket clear of the title; long titles use a two-line limit.
- English lyrics now display platform-provided Chinese `tlyric` / `ytlrc` subtitles under the original line. Timestamp matching preserves missing lines instead of shifting translations; plain original lyrics remain readable when the platform supplies no translation.
- The native player, cloud bridge, Album Identity, Pressing Studio and playback controls are unchanged; frontend lyric loading and rendering now include translated lyrics.
- Hold the outer record groove for 290ms to enter angular song-position preview; rotate to locate, release to seek.
- Pointer cancel restores the existing play position; holding the label still opens the queue; swipe to skip, tap to play/pause.
- Stable nonrotating hit geometry, accessible conventional seek slider, 30px touch target, keyboard seek; respect reduced-motion settings.
- Record seek has its own compact readout, without a second generic scrub tooltip.
- Album-specific pressing and lyric folio remain unchanged.
- versionCode 151 / versionName 0.15.1.

## Verification

The visual layer is `app/src/main/assets/sleeve-edition.css`, loaded after the existing 0.15.0 styles. Removing its link restores the previous visual treatment.

`python tests/test_tangible_record.py` exercises 4 screen/theme combinations using a REAL WAV with commit/cancel checks.
`python tests/test_interaction_refinement.py`, `node tests/test_playback_clock.cjs`, `python tests/test_native_queue_contract.py`, `python tests/test_queue_100.py`, `python tests/test_album_identity.py` and `python tests/test_pressing_studio.py` cover regressions.

For this revision, the interaction, record gesture, 100-track queue and playback-clock checks run against the full stylesheet stack in Chromium on Windows. Screenshots cover warm/blue albums, 1280x720, 850x393, 740x360, 390x844, lyric folio, discovery and Chinese titles. `node --test tests/test_lyric_translations.cjs` covers exact/rounded/missing/ambiguous timestamps, duplicate translations and safe text handling. Browser checks exercise translation rendering through controlled native/network callbacks; these are not live NetEase account tests. The Android debug APK builds with JDK 17, Gradle 8.13 and SDK 35. Desktop Chromium checks do not establish physical-device font, GPU or online-platform behavior.

## Limitations

Unlicensed content is not bypassed. Netease unofficial API access and QR account authorization are not guaranteed; real-device Bluetooth, notification behavior and GPU frame time require physical Android verification. This is a test/debug build, not a production-signed release.
