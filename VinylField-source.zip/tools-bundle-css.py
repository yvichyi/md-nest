"""Reproducible, order-pinned stylesheet build; sources kept editable."""
from pathlib import Path
root=Path(__file__).resolve().parent/'app/src/main/assets'
files=['style.css','cover-theme.css','immersive-motion.css','art-direction.css','motion-engine.css','living-record.css','pressing-studio.css','album-identity.css']
css='/* VinylField build: edit source styles, then run tools-bundle-css.py. */\n'
for name in files:css+=f'\n/* BEGIN {name} */\n'+(root/name).read_text()+'\n'
(root/'ui-bundle.css').write_text(css)
index=root/'index.html';h=index.read_text()
for name in files:h=h.replace(f'  <link rel="stylesheet" href="{name}" />\n','')
h=h.replace('  </head>','  </head>') # no-op safety
if 'ui-bundle.css' not in h:h=h.replace('<head>','<head>\n  <link rel="stylesheet" href="ui-bundle.css" />',1)
index.write_text(h)
print('Bundled',len(files),'styles:',len(css),'bytes')
