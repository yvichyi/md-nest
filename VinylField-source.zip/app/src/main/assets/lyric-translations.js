/* Align platform-provided translated LRC by time, never by row number.
   Missing translations stay missing; this module does not generate text. */
(function (root) {
  'use strict';
  function mergeTranslations(original, translated, tolerance = 200) {
    const groups = new Map();
    for (const line of translated || []) {
      if (!Number.isFinite(line?.time) || !String(line.text || '').trim()) continue;
      if (!groups.has(line.time)) groups.set(line.time, new Set());
      groups.get(line.time).add(String(line.text).trim());
    }
    const times = [...groups.keys()].sort((a, b) => a - b);
    const originals = [...new Set((original || []).map(line => line.time))]
      .filter(Number.isFinite).sort((a, b) => a - b);
    const matches = new Map();
    const used = new Set();
    // Reserve every exact match before considering small timestamp rounding differences.
    for (const time of originals) {
      if (groups.has(time)) { matches.set(time, time); used.add(time); }
    }
    const budget = Math.max(0, Math.min(500, Number(tolerance) || 0));
    const remainingOriginals = originals.filter(time => !matches.has(time));
    const remainingTranslations = times.filter(time => !used.has(time));
    function closest(sorted, time) {
      let low = 0, high = sorted.length;
      while (low < high) {
        const middle = (low + high) >>> 1;
        if (sorted[middle] < time) low = middle + 1; else high = middle;
      }
      const candidates = [sorted[low - 1], sorted[low]]
        .filter(value => value !== undefined
          && Math.abs(value - time) <= budget)
        .sort((a, b) => Math.abs(a - time) - Math.abs(b - time));
      // An equally close pair is ambiguous: leave the original line untranslated.
      if (!candidates.length || (candidates.length > 1
          && Math.abs(candidates[0] - time) === Math.abs(candidates[1] - time))) return undefined;
      return candidates[0];
    }
    for (const time of remainingOriginals) {
      const translatedTime = closest(remainingTranslations, time);
      // Mutual nearest neighbours prevent an earlier verse stealing a later one's subtitle.
      if (translatedTime !== undefined && closest(remainingOriginals, translatedTime) === time)
        matches.set(time, translatedTime);
    }
    return (original || []).map(line => {
      const matched = matches.get(line.time);
      const text = matched === undefined ? '' : [...groups.get(matched)].join('\n');
      return { ...line, translation: text === line.text ? '' : text };
    });
  }
  const api = { mergeTranslations };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.VFLyricTranslations = api;
})(typeof window !== 'undefined' ? window : globalThis);
