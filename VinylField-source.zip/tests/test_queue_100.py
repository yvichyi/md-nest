from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
def bundle():
 h=(root/'index.html').read_text()
 for n in ('ui-bundle.css',):
  h=h.replace(f'<link rel="stylesheet" href="{n}" />','<style>'+ (root/n).read_text()+'</style>')
 js=(root/'app.js').read_text()
 js=js.replace('})();',"window.__vfQA={seedQueue(count){state.queue=Array.from({length:count},(_,i)=>({id:'qa-'+i,title:'音轨 '+(i+1),artist:'Test Artist',source:'local',uri:'content://fake/'+i,artwork:''}));state.index=42;renderQueue();},open(){openOverlay('queueOverlay');},locate(){locateCurrent();}};})();")
 for n in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
  data='data:image/jpeg;base64,'+base64.b64encode((root/n).read_bytes()).decode()
  h=h.replace(n,data);js=js.replace(n,data)
 h=h.replace('<script src="playback-clock.js"></script>','').replace('<script src="app.js"></script>','<script>'+ (root/'playback-clock.js').read_text()+ '\n'+(root/'pressing-studio.js').read_text()+'\n'+js+'</script>')
 return h
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(1280,720),(850,393),(390,844)]:
  p=b.new_page(viewport={'width':w,'height':h},is_mobile=True,has_touch=True)
  errors=[];p.on('pageerror',lambda err: errors.append(str(err)))
  p.set_content(bundle());p.wait_for_timeout(150)
  p.evaluate('window.__vfQA.seedQueue(100);window.__vfQA.open()');p.wait_for_timeout(600)
  initial=p.evaluate("({count:document.querySelector('#queueCount').textContent, rows:document.querySelector('#queueResults').children.length,current:document.querySelector('#queueResults .current').dataset.queueIndex,top:document.querySelector('#queueResults').scrollTop})")
  assert initial['rows']==100 and initial['count']=='100 首歌曲' and initial['current']=='42',initial
  p.evaluate("document.querySelector('#queueResults').scrollTo({top:document.querySelector('#queueResults').scrollHeight,behavior:'instant'})")
  p.wait_for_timeout(80)
  assert p.evaluate("document.querySelector('#queueResults').scrollTop+document.querySelector('#queueResults').clientHeight>=document.querySelector('#queueResults').scrollHeight-2")
  p.evaluate("window.__vfQA.locate()")
  p.wait_for_timeout(1400)
  loc=p.evaluate("({pos:document.querySelector('#queueResults').scrollTop, current:document.querySelector('#queueResults .current').getBoundingClientRect().top,top:document.querySelector('#queueResults').getBoundingClientRect().top,bottom:document.querySelector('#queueResults').getBoundingClientRect().bottom})")
  assert loc['top'] <= loc['current'] <loc['bottom'],loc
  p.screenshot(path=f'/mnt/data/VinylField-0.12.0-queue-real-{w}x{h}.png')
  print('PASS 100-track queue',w,h,initial,loc,'js errors',errors)
  assert not errors,errors
  p.close()
 b.close()
