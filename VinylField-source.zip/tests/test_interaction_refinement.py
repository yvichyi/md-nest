from pathlib import Path
import base64, math, wave, struct, tempfile, json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets'
OUT=Path('/mnt/data/VinylField-0.14.5-evidence'); OUT.mkdir(exist_ok=True)

def bundle(theme='warm'):
    html=(ROOT/'index.html').read_text()
    for fn in ('ui-bundle.css','controls-refined.css','optical-editorial.css','tangible-record.css','sleeve-edition.css'):
        html=html.replace(f'<link rel="stylesheet" href="{fn}" />','<style>'+ (ROOT/fn).read_text()+'</style>')
    imgs={name:'data:image/jpeg;base64,'+base64.b64encode((ROOT/name).read_bytes()).decode() for name in ('demo-coffee-cover.jpg','demo-orbit-cover.jpg')}
    for k,v in imgs.items():html=html.replace('"'+k+'"','"'+v+'"')
    for fn in ('playback-clock.js','album-identity.js','pressing-studio.js','lyric-translations.js','app.js'):
        js=(ROOT/fn).read_text()
        if fn=='app.js':
            js=js.replace("new URLSearchParams(location.search).get('demo')",repr(theme))
            for k,v in imgs.items():js=js.replace(k,v)
        html=html.replace(f'<script src="{fn}"></script>','<script>'+js+'</script>')
    assert '<script src=' not in html and '<link rel="stylesheet"' not in html
    return html

fixture=Path(tempfile.gettempdir())/'vf-144-real-12s.wav'
with wave.open(str(fixture),'wb') as f:
    f.setnchannels(1);f.setsampwidth(2);f.setframerate(16000)
    f.writeframes(b''.join(struct.pack('<h',int(2600*math.sin(2*math.pi*220*i/16000))) for i in range(16000*12)))

with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
    stats=[]
    for theme,w,h in [('warm',1280,720),('blue',1280,720),('warm',850,393),('warm',390,844)]:
        page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1,has_touch=True,is_mobile=(w==390))
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(bundle(theme),wait_until='load',timeout=30000)
        page.wait_for_timeout(500)
        buttons=[page.locator('#'+n).bounding_box() for n in ('prevBtn','playBtn','nextBtn')]
        assert all(0<=x['x'] and 0<=x['y'] and x['x']+x['width']<=w+1 and x['y']+x['height']<=h+1 for x in buttons),(w,h,buttons)
        assert not page.evaluate('document.documentElement.scrollWidth > innerWidth+1'), (w,h)
        # Focus mode remains identifiable and reversible
        page.locator('#focusToggle').click()
        assert page.locator('#focusLabel').inner_text()=='返回唱片'
        assert page.locator('#focusToggle').get_attribute('aria-pressed')=='true'
        page.locator('#focusToggle').click()
        assert page.locator('#focusLabel').inner_text()=='歌词内页'
        # Built-in demo exposes timestamped lines, so lyric preview is real data.
        slider=page.locator('#seekSlider')
        slider.evaluate("el=>{el.value=620;el.dispatchEvent(new Event('input',{bubbles:true}));}")
        assert page.locator('#seekFeedback').get_attribute('aria-hidden')=='false'
        preview=page.locator('#seekPreviewLyric').inner_text()
        assert preview and '定位到歌曲中的这一刻' not in preview,preview
        assert page.locator('#seekPreviewTime').inner_text()!='00:00'
        assert not errors,errors
        page.screenshot(path=str(OUT/f'{theme}-{w}x{h}-scrubbing.png'))
        slider.evaluate("el=>el.dispatchEvent(new Event('change',{bubbles:true}))")
        page.wait_for_timeout(280)
        assert page.locator('#seekFeedback').get_attribute('aria-hidden')=='true'
        page.locator('#toolsToggle').click(); assert page.locator('#toolsToggle').get_attribute('aria-expanded')=='true'
        page.locator('#queueBtn').click(); assert page.locator('#queueOverlay').get_attribute('aria-hidden')=='false'
        page.locator('#closeQueue').click()
        page.locator('#toolsToggle').click()
        page.locator('#searchBtn').click(); assert page.locator('#libraryOverlay').get_attribute('aria-hidden')=='false'
        page.locator('#closeLibrary').click()
        assert not errors,errors
        stats.append({'theme':theme,'viewport':f'{w}x{h}','lyric_preview':preview,'console_errors':errors})
        page.close()

    # Real audio test: timeline preview while scrubbing must not seek until commit.
    page=b.new_page(viewport={'width':1280,'height':720})
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(bundle(),wait_until='load')
    page.locator('#browserFile').set_input_files(str(fixture))
    page.wait_for_function("document.querySelector('#totalTime').textContent !== '00:00' && VF.motionSnapshot().position > 0", timeout=15000)
    page.wait_for_timeout(600)
    assert page.evaluate('document.body.classList.contains("is-playing")')
    current=page.evaluate('window.VF.motionSnapshot().position')
    slider=page.locator('#seekSlider')
    slider.evaluate("el=>{el.value=850;el.dispatchEvent(new Event('input',{bubbles:true}));}")
    page.wait_for_timeout(170)
    during=page.evaluate('window.VF.motionSnapshot().position')
    assert abs(during-current)<600, (current,during)
    assert page.locator('#seekPreviewLyric').inner_text()=='定位到歌曲中的这一刻'
    slider.evaluate("el=>el.dispatchEvent(new Event('pointercancel',{bubbles:true}))")
    page.wait_for_timeout(100)
    assert abs(page.evaluate('window.VF.motionSnapshot().position')-current)<1000
    slider.evaluate("el=>{el.value=500;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}")
    page.wait_for_timeout(180)
    position=page.evaluate('window.VF.motionSnapshot().position')
    assert 4800<=position<=6600,(position,current)
    assert not errors,errors
    stats.append({'real_audio':True,'seek_before_commit_ms':round(current),'after_commit_ms':round(position),'cancel_did_not_seek':True})
    b.close()
    (OUT/'interaction-results.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
    print('PASS 4 viewport-theme combinations, lyric preview, focus, queue, search, real WAV seek commit/cancel')
    print(json.dumps(stats,ensure_ascii=False,indent=2))
