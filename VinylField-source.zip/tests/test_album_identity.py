"""Visual regressions for album identity; browser witness, not Android performance attestation."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets'
LAB=(Path(__file__).resolve().parent/'fixtures/album-identity-lab.html').read_text()
def bundle_player(key):
 import base64
 s=(ROOT/'index.html').read_text()
 for sheet in ('ui-bundle.css','controls-refined.css'):
  s=s.replace(f'<link rel="stylesheet" href="{sheet}" />','<style>'+ (ROOT/sheet).read_text() +'</style>')
 for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
  s=s.replace(name,'data:image/jpeg;base64,'+base64.b64encode((ROOT/name).read_bytes()).decode())
 for name in ['playback-clock.js','album-identity.js','pressing-studio.js','app.js']:
  js=(ROOT/name).read_text()
  if name=='app.js':
   js=js.replace("new URLSearchParams(location.search).get('demo')", repr(key))
   for fname in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
    dataurl='data:image/jpeg;base64,'+base64.b64encode((ROOT/fname).read_bytes()).decode()
    js=js.replace(fname,dataurl)
  s=s.replace(f'<script src="{name}"></script>','<script>'+js+'</script>')
 return s
out=Path('/mnt/data/VinylField-0.14.5-evidence');out.mkdir(exist_ok=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 lab=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
 errors=[]
 lab.on('pageerror',lambda e:errors.append(str(e)))
 lab.set_content(LAB,wait_until='load',timeout=45000)
 lab.locator('.cover-btn').first.wait_for()
 assert lab.locator('.cover-btn').count()==10
 profiles=[]
 for i in range(10):
  lab.locator('.cover-btn').nth(i).click()
  pp=lab.evaluate('window.__identityLab.profile')
  profiles.append({'name':lab.locator('#recordName').inner_text(),'identity':pp['identity'],'brightness':pp['stats']['brightness'],'contrast':pp['contrast'],'accent':pp['accent'],'paper':pp['paper']})
  assert pp['contrast']>=4.5,(i,pp)
  assert not errors,errors
  assert not lab.evaluate('document.documentElement.scrollWidth > innerWidth+2')
 assert len(set(x['identity'] for x in profiles))>=4,profiles
 assert len(set(x['primary'] if 'primary' in x else x['accent'] for x in profiles))>=7,profiles
 lab.locator('.cover-btn').nth(1).click()
 night=lab.evaluate('window.__identityLab.profile')
 # Night sky must choose low-luminance profile, not amber because of tiny red light.
 assert night['identity']=='nocturne',night
 lab.locator('.cover-btn').nth(6).click()
 before=lab.evaluate('JSON.stringify(window.__identityLab.profile)')
 lab.locator('.cover-btn').nth(1).click()
 lab.locator('.cover-btn').nth(6).click()
 assert lab.evaluate('JSON.stringify(window.__identityLab.profile)')==before
 lab.locator('#compare').click()
 assert lab.locator('#compare').get_attribute('aria-pressed')=='true'
 lab.locator('#compare').click()
 assert lab.locator('#compare').get_attribute('aria-pressed')=='false'
 lab.locator('.cover-btn').nth(2).click()
 lab.screenshot(path=str(out/'identity-lab-wide.png'),full_page=True)
 (out/'profiles.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2))
 print('PROFILES',json.dumps(profiles,ensure_ascii=False))
 for wh in [(390,844),(850,393)]:
  pg=browser.new_page(viewport={'width':wh[0],'height':wh[1]},device_scale_factor=1)
  pg.set_content(LAB,wait_until='load',timeout=45000)
  pg.locator('.cover-btn').nth(1).click()
  assert not pg.evaluate('document.documentElement.scrollWidth > innerWidth+2'),wh
  pg.screenshot(path=str(out/f'identity-lab-{wh[0]}x{wh[1]}.png'),full_page=True)
  pg.close()
 # actual app UI: two bundled covers and identity applied on image decode
 for key in ['warm','blue']:
  pg=browser.new_page(viewport={'width':1280,'height':720},device_scale_factor=1)
  pg.set_content(bundle_player(key),wait_until='load',timeout=45000)
  pg.wait_for_function('(key)=>window.VFAlbumIdentity.last?.key === "vf-demo-"+key',arg=key,timeout=20000)
  profile=pg.evaluate('window.VFAlbumIdentity.last')
  assert profile['contrast']>=4.5,(key,profile)
  assert pg.locator('#recordCover').is_visible(),key
  assert not pg.evaluate('document.documentElement.scrollWidth > innerWidth+2')
  pg.screenshot(path=str(out/f'player-{key}-1280x720.png'))
  print('ACTUAL APP',key,profile['identity'],profile['primary'])
  pg.close()
 assert not errors,errors
 lab.close();browser.close()
 print('PASS all; distinct identities',len(set(x['identity'] for x in profiles)))
