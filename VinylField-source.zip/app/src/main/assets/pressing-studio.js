/* VinylField 0.13 — cover-derived pressing, generated only on artwork changes.
   No WebGL dependency, no animation-time pixel work, deterministic for an album ID. */
(function(root) {
  'use strict';
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const toHex=rgb=>'#'+rgb.map(v=>Math.round(clamp(v,0,255)).toString(16).padStart(2,'0')).join('');
  const fromHex=h=>/^#[0-9a-f]{6}$/i.test(h||'')?[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)):[157,137,127];
  function hash(s) {let h=2166136261;for(const c of String(s)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0;}
  const mix=(a,b,t)=>a.map((v,i)=>v*(1-t)+b[i]*t);
  const luminance=c=>(.2126*c[0]+.7152*c[1]+.0722*c[2])/255;
  function paletteFromPixels(data,fallback) {
    const bins=Array.from({length:12},(_,i)=>({w:0,r:0,g:0,b:0,hueIndex:i}));
    let colored=0,bright=0,dark=0,total=0,grey=[0,0,0];
    for(let i=0;i<data.length;i+=32){
      if(data[i+3]<190)continue;
      const rgb=[data[i],data[i+1],data[i+2]];
      const mx=Math.max(...rgb),mn=Math.min(...rgb),delta=mx-mn;
      total++;grey=grey.map((v,k)=>v+rgb[k]);
      if(mx<66)dark++;if(mn>210)bright++;
      if(delta<25||mx<38||mn>242)continue;
      let hue;
      if(mx===rgb[0])hue=((rgb[1]-rgb[2])/delta)%6;
      else if(mx===rgb[1])hue=(rgb[2]-rgb[0])/delta+2;
      else hue=(rgb[0]-rgb[1])/delta+4;
      hue=(hue*60+360)%360;
      const k=Math.floor(hue/30)%12;
      const saturation=delta/(mx||1),weight=.55+Math.min(1,saturation)*.75;
      const bin=bins[k];bin.w+=weight;
      bin.r+=rgb[0]*weight;bin.g+=rgb[1]*weight;bin.b+=rgb[2]*weight;colored++;
    }
    bins.sort((a,b)=>b.w-a.w);
    const base=fromHex(fallback);
    // Night photography commonly has tiny red/orange highlights over a cool field.
    // Preserve that scene character rather than using the brightest isolated star.
    const night=total>0 && dark/total>.55;
    const cool=bins.find(v=>v.hueIndex>=6 && v.hueIndex<=9 && v.w>=Math.max(1.2,bins[0].w*.085));
    if(night&&cool&&bins[0]!==cool){bins.splice(bins.indexOf(cool),1);bins.unshift(cool);}
    let a=bins[0].w>0?[bins[0].r,bins[0].g,bins[0].b].map(x=>x/bins[0].w):base;
    // Ignore isolated highlights: a second pigment must cover >=12% of chromatic samples.
    const bBin=bins.find((bin,i)=>i>0&&bin.w>=Math.max(3,bins[0].w*.17));
    const b=bBin?[bBin.r,bBin.g,bBin.b].map(x=>x/bBin.w):mix(a,[235,222,207],.22);
    const variation=bBin?bBin.w/(bins[0].w+bBin.w):0;
    let finish='clear';
    if(total && bright/total>.55)finish='pearl';
    else if(total && dark/total>.58)finish='smoke';
    else if(variation>.33&&colored>45)finish='marble';
    else if(variation>.19&&colored>25)finish='duotone';
    const neutral=total?grey.map(v=>v/total):base;
    // Inks are translucent: introduce paper/light through all pigments.
    a=mix(a,[239,223,209],finish==='smoke'?.22:.43);
    return {a,b:mix(b,[250,237,227],finish==='smoke'?.18:.48),neutral,finish,variation,ratio:total?colored/total:0};
  }
  function sampleImage(image,fallback){
    const canvas=document.createElement('canvas');canvas.width=84;canvas.height=84;
    const ctx=canvas.getContext('2d',{willReadFrequently:true});
    ctx.drawImage(image,0,0,84,84);
    const pixels=ctx.getImageData(0,0,84,84);
    return {info:paletteFromPixels(pixels.data,fallback),pixels};
  }
  function drawTexture(info,seed) {
    const size=320,half=size/2;
    const canvas=document.createElement('canvas');canvas.width=canvas.height=size;
    const ctx=canvas.getContext('2d');const img=ctx.createImageData(size,size),out=img.data;
    const phase=(seed%65536)/65536*Math.PI*2;
    const finish=info.finish;
    const a=info.a,b=info.b;
    for(let y=0;y<size;y++){
      for(let x=0;x<size;x++){
        const px=(x-half+.5)/half,py=(y-half+.5)/half;
        const radius=Math.sqrt(px*px+py*py),index=(y*size+x)*4;
        if(radius>1){out[index+3]=0;continue;}
        const angle=Math.atan2(py,px);
        const swirl=Math.sin(angle*2.2+radius*9+phase+.28*Math.cos(angle*5-radius*8));
        const ribbon=Math.sin(angle*3-radius*14+phase+swirl*.42);
        let t=.31;
        if(finish==='marble')t=clamp(.5+.44*Math.sin(angle*2.8+radius*13+phase+.65*swirl),.07,.93);
        else if(finish==='duotone')t=clamp(.44+.36*ribbon,.09,.83);
        else if(finish==='pearl')t=.35+.10*swirl;
        else if(finish==='smoke')t=.27+.19*ribbon;
        else t=.26+.16*swirl;
        const v=mix(a,b,t);
        // Independently lit microgrooves: highlights tied to surface normals,
        // not a large flat rotating gradient painted over the artwork.
        const groove=Math.pow(Math.max(0,Math.sin(radius*810 + .5*Math.sin(angle*4))),16);
        const edge=Math.pow(radius,12);
        const spec=Math.pow(Math.max(0,Math.cos(angle-2.2)),10)*(0.07+.08*radius);
        const noise=(Math.imul(x>>1,1103515245)^Math.imul(y>>1,12345)^seed)>>>0;
        const grain=((noise&255)/255-.5)*2.8;
        const shade=1+(groove*.042)-(edge*.066)+spec;
        out[index]=clamp(v[0]*shade+grain,0,255);
        out[index+1]=clamp(v[1]*shade+grain,0,255);
        out[index+2]=clamp(v[2]*shade+grain,0,255);
        out[index+3]=255;
      }
    }
    ctx.putImageData(img,0,0);
    return canvas.toDataURL('image/png');
  }
  let generation=0;
  const cache=new Map();
  function install(imageUrl,key,primary='#9a8780') {
    const token=++generation;
    const base=paletteFromPixels([],primary);
    // Keep former material while new cover is loading. A network error is not
    // permission to leak the previous track's artwork or use a random texture.
    const img=new Image();img.crossOrigin='anonymous';
    function commit(info,pixels){
      if(token!==generation)return;
      const signature=`${key}|${toHex(info.a)}|${toHex(info.b)}|${info.finish}`;
      let texture=cache.get(signature);
      if(!texture){texture=drawTexture(info,hash(signature));cache.set(signature,texture);if(cache.size>8)cache.delete(cache.keys().next().value);}
      const vinyl=document.getElementById('vinyl');if(!vinyl)return;
      vinyl.style.setProperty('--vf-pressing-image',`url("${texture}")`);
      document.body.dataset.pressingFinish=info.finish;
      vinyl.dataset.pressKey=key;
      vinyl.dataset.material=info.finish;
      document.documentElement.style.setProperty('--vf-resin-shade',toHex(info.a));
      document.documentElement.style.setProperty('--vf-resin-glint',toHex(info.b));
      if(root.VFPressingStudio)root.VFPressingStudio.last={key,finish:info.finish,pigments:[toHex(info.a),toHex(info.b)],signature};
      if(root.VFAlbumIdentity){const profile=pixels?root.VFAlbumIdentity.analyze(pixels,pixels.width,pixels.height,key):root.VFAlbumIdentity.fallback(primary,key);root.VFAlbumIdentity.apply(profile,key);}
    }
    if(!imageUrl){commit(base);return;}
    img.onload=()=>{
      if(token!==generation)return;
      try{const sampled=sampleImage(img,primary);commit(sampled.info,sampled.pixels);}catch(_){commit(base);}
    };
    img.onerror=()=>{if(token===generation)commit(base);};
    img.src=imageUrl;
    if(img.complete&&img.naturalWidth>0)img.onload();
  }
  root.VFPressingStudio={install,last:null,analyze:paletteFromPixels,renderTexture:drawTexture,hash};
})(window);
