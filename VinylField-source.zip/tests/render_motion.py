from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
output=Path('/mnt/data')

def bundled(kind=None,native=False):
    html=(root/'index.html').read_text()
    for name in ['ui-bundle.css']:
        html=html.replace(f'<link rel="stylesheet" href="{name}" />', '<style>'+ (root/name).read_text() +'</style>')
    for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
        html=html.replace(name,'data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode())
    clock=(root/'playback-clock.js').read_text()
    js=(root/'app.js').read_text()
    for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
        js=js.replace(name,'data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode())
    if kind:
        js=js.replace("const visualDemo = !native && new URLSearchParams(location.search).get('demo');",f"const visualDemo = '{kind}';")
    native_js='''window.Vinyl={setChromeColour(){},playLocalQueue(...args){window.__nativeQueue=args;},play(){},setQueueMode(){},playQueueIndex(){},next(){},previous(){},seek(){},pause(){},resume(){},pickAudio(){},landscape(){},portrait(){}};''' if native else ''
    html=html.replace('<script src="playback-clock.js"></script>','').replace('<script src="pressing-studio.js"></script>','').replace('<script src="app.js"></script>',f'<script>{native_js}\n{clock}\n{(root/"pressing-studio.js").read_text()}\n{js}</script>')
    return html

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
    for w,h,kind in [(1280,720,'warm'),(1280,720,'blue'),(850,393,'warm'),(390,844,'warm')]:
        page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(bundled(kind),wait_until='load',timeout=30000)
        page.wait_for_timeout(600)
        stage=page.locator('#stage').bounding_box();disc=page.locator('.deck-frame').bounding_box()
        assert stage and disc
        current=page.locator('.lyric-line.active').count()
        overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth + 2')
        assert not errors,errors
        assert not overflow,(w,h)
        assert current==1,(w,h,current)
        page.screenshot(path=str(output/f'VinylField-0.12.0-{kind}-{w}x{h}.png'))
        print('PASS VIEWPORT',w,h,kind,'active lyrics',current,'disc',tuple(round(disc[x]) for x in ('width','height')))
        page.close()
    page=browser.new_page(viewport={'width':1280,'height':720})
    page.set_content(bundled('warm'),wait_until='load')
    page.wait_for_timeout(300)
    initial=page.locator('#recordCover').get_attribute('src')
    page.evaluate('window.VFPreview.switchAlbum("blue")')
    page.wait_for_timeout(1050)
    final=page.locator('#recordCover').get_attribute('src')
    print('ART SOURCE',len(initial or ''),len(final or ''),str(initial)[:75],str(final)[:75]);assert initial!=final and final.startswith('data:image/jpeg')
    assert page.locator('#songTitle').inner_text()=='Between the Stars'
    assert page.locator('#recordCover').is_visible()
    print('PASS artwork and song transition')
    page.close()
    # Native state snapshots drive motion, not the stand-alone CSS animation.
    page=browser.new_page(viewport={'width':1280,'height':720})
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(bundled(native=True),wait_until='load')
    page.evaluate("window.VF.addLocalTrack('content://media/a/1','Song.mp3')")
    media_id=page.evaluate('JSON.parse(window.__nativeQueue[0])[0].id')
    def deliver(position,playing,buffering):
        page.evaluate('''s=>window.VF.onNativeState(s)''',{'hasItem':True,'playing':playing,'buffering':buffering,'position':position,'duration':60000,'mediaId':media_id,'mediaIndex':0,'queueCount':1})
    deliver(12000,True,False)
    page.wait_for_timeout(900)
    snapshot1=page.evaluate('window.VF.motionSnapshot()')
    assert snapshot1['velocity']>1,snapshot1
    deliver(12900,False,False)
    page.wait_for_timeout(2000)
    snapshot2=page.evaluate('window.VF.motionSnapshot()')
    assert snapshot2['velocity']<snapshot1['velocity'],(snapshot1,snapshot2)
    assert abs(snapshot2['position']-12900)<5,snapshot2
    deliver(12900,True,True)
    page.wait_for_timeout(450)
    snapshot3=page.evaluate('window.VF.motionSnapshot()')
    assert abs(snapshot3['position']-12900)<5,snapshot3
    assert not errors,errors
    print('PASS motion pause inertia and buffering freeze',snapshot1,snapshot2,snapshot3)
    page.close();browser.close()
