from pathlib import Path
import base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
for theme in ('warm','blue'):
    html=(root/'index.html').read_text()
    for fn in ('ui-bundle.css','controls-refined.css','optical-editorial.css'):
        html=html.replace(f'<link rel="stylesheet" href="{fn}" />','<style>'+ (root/fn).read_text()+'</style>')
    imgs={name:'data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode() for name in ('demo-coffee-cover.jpg','demo-orbit-cover.jpg')}
    for name,data in imgs.items(): html=html.replace(f'"{name}"',f'"{data}"')
    for fn in ('playback-clock.js','album-identity.js','pressing-studio.js','app.js'):
        js=(root/fn).read_text()
        if fn=='app.js':
            js=js.replace("new URLSearchParams(location.search).get('demo')",repr(theme))
            for name,data in imgs.items():js=js.replace(name,data)
        html=html.replace(f'<script src="{fn}"></script>','<script>'+js+'</script>')
    assert 'controls-integrated.css' not in html and '<link rel="stylesheet"' not in html and '<script src=' not in html
    dst=Path(f'/mnt/data/VinylField-0.14.5-{theme}-preview.html');dst.write_text(html)
    print(dst,dst.stat().st_size)
