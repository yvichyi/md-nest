# VinylField 0.11.0 — Motion Engine

Unofficial third-party Android music player inspired by a QQ Music landscape colour-vinyl composition. Not associated with QQ Music or NetEase Cloud Music. Album artwork, login and lyrics require applicable provider access and permissions.

## What changed from 0.10.1

**Playback Clock** (`app/src/main/assets/playback-clock.js`): one monotonic, independently unit-tested visual audio clock. Media3 snapshots remain authoritative, with bounded soft drift correction during normal playback and hard resync on seek, pause, buffer changes and media identity switch. The derived position drives the seekbar and line-level LRC progress. The platter never decides whether audio is actually playing.

**Disc and optics**: integrated angular velocity with smooth acceleration/deceleration and persistent phase; reflections move slowly in room coordinates instead of spinning rigidly with the artwork. Backgrounded WebViews suspend animation frames and resume from subsequent native state snapshots. Honors reduced-motion preference.

**Lyrics**: stable font metrics for active and inactive lines, composite overlay for line-level highlight (not fabricated word-level timestamps), touch-to-seek and accessible text unchanged. Reduced DOM style churn, no active-line font-size-induced reflow.

**Transitions**: existing double-buffered artwork preserved. Track intro and lyric area share defined entrance timing, disc does not scale-jump on every track change.

**Native handshake**: starting a new track does not mark it playing until Media3 acknowledges the exact media ID. Late events for the previous media ID are ignored while loading. 12-second timeout for never-acknowledged starts; pre-existing native error paths preserved.

App version: `0.11.0` / `versionCode 12`. UI/footer aligned.

## What is verified

Run in project root:

- `node tests/test_playback_clock.cjs` — deterministic clock behavior (periodic jitter, pause, buffering, seek, track changes, bounded duration).
- `python tests/test_native_queue_contract.py` — mock bridge local-queue transport, ignore stale native state during track load, navigation, shuffle, orphan session restore.
- `python tests/render_motion.py` — Chromium visual/layout states (1280×720 warm/blue, 850×393, 390×844), cover swap, native state motion, buffer freeze; snapshots are saved in `/mnt/data` in this development environment.
- `python tests/test_audio_motion.py` — local WAV browser playback drives actual progress and disc velocity, then pause freezes the reported clock while disc slows.

Tests use Chromium/Playwright for browser simulation, not physical Android hardware. There is no evidence yet for live NetEase login, real network playback, Bluetooth skip or GPU frame-time behavior on a device.

## Build

JDK 17, Android SDK 35, Gradle 8.11.1. Run `gradle --no-daemon :app:assembleDebug`. Workflow `.github/workflows/android.yml` builds on main/master or manual trigger. **A passing script or downloaded source is not evidence that APK has been built**; inspect actual CI output before distributing.

## Limitations

- LRC-only time data supports line-level progress, not precise karaoke word timing.
- Album colour extraction and native networking inherit limitations from 0.10.1.
- NetEase stream URLs remain resolved on demand (no preloaded cloud queue).
- Visual performance is not independently profiled on hardware.
