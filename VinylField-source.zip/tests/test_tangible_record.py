from pathlib import Path
import base64, tempfile, struct, wave, math, json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets'
OUT=Path('/mnt/data/VinylField-0.15.0-evidence');OUT.mkdir(exist_ok=True)
def bundle(theme):
    html=(ROOT/'index.html').read_text()
    for fn in ('ui-bundle.css','controls-refined.css','optical-editorial.css','tangible-record.css','sleeve-edition.css'):
        html=html.replace(f'<link rel="stylesheet" href="{fn}" />','<style>'+ (ROOT/fn).read_text()+'</style>')
    imgs={name:'data:image/jpeg;base64,'+base64.b64encode((ROOT/name).read_bytes()).decode() for name in ('demo-coffee-cover.jpg','demo-orbit-cover.jpg')}
    for name,data in imgs.items(): html=html.replace('"'+name+'"','"'+data+'"')
    for fn in ('playback-clock.js','album-identity.js','pressing-studio.js','lyric-translations.js','app.js'):
        js=(ROOT/fn).read_text()
        if fn=='app.js':
            js=js.replace("new URLSearchParams(location.search).get('demo')",repr(theme))
            for k,v in imgs.items():js=js.replace(k,v)
        html=html.replace(f'<script src="{fn}"></script>','<script>'+js+'</script>')
    assert '<script src=' not in html
    return html
fixture=Path(tempfile.gettempdir())/'vinylfield-15-test.wav'
if not fixture.is_file():
    with wave.open(str(fixture),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(16000)
        f.writeframes(b''.join(struct.pack('<h',int(2500*math.sin(2*math.pi*220*i/16000))) for i in range(16000*20)))
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
    report=[]
    for theme,w,h in [('warm',1280,720),('blue',1280,720),('warm',850,393),('warm',390,844)]:
        page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1,has_touch=True,is_mobile=(w==390))
        errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
        page.set_content(bundle(theme),wait_until='load',timeout=30000)
        page.locator('#browserFile').set_input_files(str(fixture))
        page.wait_for_function("document.querySelector('#totalTime').textContent !== '00:00' && VF.motionSnapshot().position > 0", timeout=15000)
        page.wait_for_timeout(450)
        info=page.locator('.vinyl-well').bounding_box(); assert info,(w,h)
        cx=info['x']+info['width']/2;cy=info['y']+info['height']/2;r=info['width']/2
        # The intended hold works only on outer annulus; the center keeps existing gestures.
        x=cx+r*.83;y=cy
        page.mouse.move(x,y);page.mouse.down();page.wait_for_timeout(365)
        assert 'is-disc-scrubbing' in page.locator('.deck-frame').get_attribute('class'),(w,h,'rim mode failed')
        first=page.evaluate('VF.motionSnapshot().position')
        page.mouse.move(cx,cy-r*.83,steps=6)
        page.wait_for_timeout(80)
        assert page.locator('#deckSeekReadout').get_attribute('aria-hidden')=='false'
        assert '00:00' in page.locator('#deckSeekReadout').inner_text()
        mid=page.evaluate('VF.motionSnapshot().position')
        assert abs(mid-first)<500,(w,h,'premature seek',first,mid)
        page.screenshot(path=str(OUT/f'{theme}-{w}x{h}-tangible.png'))
        page.mouse.up();page.wait_for_timeout(150)
        assert 'is-disc-scrubbing' not in page.locator('.deck-frame').get_attribute('class')
        assert page.locator('#deckSeekReadout').get_attribute('aria-hidden')=='true'
        # Set a known seek position via the normal timeline, then cancel the record gesture.
        slider=page.locator('#seekSlider');slider.evaluate("e=>{e.value=600;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}")
        page.wait_for_timeout(80)
        before=page.evaluate('VF.motionSnapshot().position')
        page.mouse.move(x,y);page.mouse.down();page.wait_for_timeout(340)
        assert 'is-disc-scrubbing' in page.locator('.deck-frame').get_attribute('class')
        page.mouse.move(cx,cy-r*.83,steps=4)
        page.locator('.deck-frame').dispatch_event('pointercancel',{'pointerId':1})
        page.mouse.up();page.wait_for_timeout(80)
        after=page.evaluate('VF.motionSnapshot().position')
        assert abs(after-before)<1600,(w,h,'cancel moved playback',before,after)
        assert not errors,errors
        report.append({'viewport':f'{w}x{h}','theme':theme,'seek_preview_without_commit':True,'pointercancel_restores':True,'errors':errors})
        page.close()
    browser.close()
    (OUT/'tangible-test-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print('PASS tangible disc real WAV on 4 viewports; rim hold, angular preview, no early seek, cancellation, no page errors')
    print(json.dumps(report,ensure_ascii=False))
