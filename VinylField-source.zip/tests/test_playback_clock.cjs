'use strict';
const assert = require('node:assert/strict');
const Clock = require('../app/src/main/assets/playback-clock.js');
const near = (a,b,eps=1)=>assert.ok(Math.abs(a-b)<=eps,`${a} not within ${eps} of ${b}`);
const c = new Clock();
// A monotonic audio-linked clock: play advances, pause locks, resume has no jump.
c.observe({mediaId:'a',position:10000,duration:200000,playing:true,buffering:false},1000,'track');
near(c.sample(1500),10500);
c.observe({mediaId:'a',position:10475,duration:200000,playing:true,buffering:false},1500);
assert.equal(c.lastReason,'corrected');
assert.ok(c.sample(1500) > 10490 && c.sample(1500) < 10500);
c.observe({mediaId:'a',position:10500,duration:200000,playing:false,buffering:false},1520);
near(c.sample(3500),10500);
c.observe({mediaId:'a',position:10500,duration:200000,playing:true,buffering:false},3500);
near(c.sample(4400),11400);
// Buffering is not playable: freeze, then re-anchor without overrun.
c.observe({mediaId:'a',position:11400,duration:200000,playing:true,buffering:true},4400);
near(c.sample(6000),11400);
c.observe({mediaId:'a',position:11420,duration:200000,playing:true,buffering:false},6000);
near(c.sample(6400),11820);
// Seek and different track are discontinuities (never smooth across them).
c.observe({mediaId:'a',position:90000,duration:200000,playing:true,buffering:false},6500,'seek');
near(c.sample(6500),90000);
c.observe({mediaId:'b',position:0,duration:93000,playing:true,buffering:false},6600);
assert.equal(c.lastReason,'snap');near(c.sample(6600),0);
// Small jitter corrected smoothly, extreme error must snap.
c.observe({mediaId:'b',position:1030,duration:93000,playing:true,buffering:false},7600);
assert.equal(c.lastReason,'corrected');
c.observe({mediaId:'b',position:25000,duration:93000,playing:true,buffering:false},7700);
near(c.sample(7700),25000);assert.equal(c.lastReason,'snap');
near(c.sample(200000),93000);
// Unknown duration never clamped to zero.
const d = new Clock();d.observe({mediaId:'',position:0,duration:0,playing:true},0,'track');near(d.sample(250),250);
console.log('PASS clock: periodic jitter, pause/resume, buffering, seek, track switch, drift, end bound');
