from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
out=Path('/mnt/data')

def embed(demo='warm'):
    html=(root/'index.html').read_text()
    css=(root/'ui-bundle.css').read_text()
    html=html.replace('<link rel="stylesheet" href="ui-bundle.css" />','<style>'+css+'</style>')
    for n in ('demo-coffee-cover.jpg','demo-orbit-cover.jpg'):
        data='data:image/jpeg;base64,'+base64.b64encode((root/n).read_bytes()).decode()
        html=html.replace(n,data)
    scripts='\n'.join((root/n).read_text() for n in ('playback-clock.js','pressing-studio.js','app.js'))
    for n in ('demo-coffee-cover.jpg','demo-orbit-cover.jpg'):
        data='data:image/jpeg;base64,'+base64.b64encode((root/n).read_bytes()).decode()
        scripts=scripts.replace(n,data)
    scripts=scripts.replace("const visualDemo = !native && new URLSearchParams(location.search).get('demo');",f"const visualDemo = '{demo}';")
    html=html.replace('<script src="playback-clock.js"></script>','').replace('<script src="pressing-studio.js"></script>','').replace('<script src="app.js"></script>','<script>'+scripts+'</script>')
    return html

with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    for demo in ('warm','blue'):
      page=b.new_page(viewport={'width':1280,'height':720})
      errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
      html=embed(demo)
      page.set_content(html,wait_until='load',timeout=30000)
      page.wait_for_function('window.VFPressingStudio?.last?.key?.startsWith("vf-demo")',timeout=15000)
      page.wait_for_timeout(450)
      art=page.locator('#recordCover')
      assert art.is_visible() and page.evaluate('document.querySelector("#recordCover").naturalWidth>0')
      assert page.locator('#songTitle').inner_text() in ('Sunday Afternoon','Between the Stars')
      assert not errors,errors
      path=out/f'VinylField-0.13.0-{demo}.png'
      page.screenshot(path=str(path))
      print('RENDER',demo,page.evaluate('window.VFPressingStudio.last'),path.stat().st_size)
      (out/f'VinylField-0.13.0-{demo}-preview.html').write_text(html)
      page.close()
    # Test that late artwork decoding cannot recolor a newer album.
    page=b.new_page(viewport={'width':850,'height':393})
    page.set_content(embed('warm'),wait_until='load')
    page.wait_for_function('window.VFPressingStudio?.last?.key === "vf-demo-warm"',timeout=12000)
    page.evaluate('window.VFPreview.switchAlbum("blue")')
    page.wait_for_function('window.VFPressingStudio?.last?.key === "vf-demo-blue"',timeout=12000)
    page.wait_for_timeout(400)
    assert page.evaluate('window.VFPressingStudio.last.key')=='vf-demo-blue'
    assert page.evaluate('document.querySelector("#recordCover").naturalWidth>0')
    page.screenshot(path=str(out/'VinylField-0.13.0-short.png'))
    print('PASS album switch no stale material; short horizontal viewport')
    page.close();b.close()
