/* VinylField 0.14 Album Identity: deterministic visual analysis, not musical genre inference.
   Reads only locally decoded artwork pixels; never uploads imagery. */
(function(root){
 'use strict';
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 const hex=c=>'#'+c.map(x=>Math.round(clamp(x,0,255)).toString(16).padStart(2,'0')).join('');
 const rgb=h=>/^#[0-9a-f]{6}$/i.test(h||'')?[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)):[146,133,131];
 const mix=(a,b,t)=>a.map((v,i)=>v*(1-t)+b[i]*t);
 const srgb=v=>{v/=255;return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4)};
 const lum=v=>.2126*srgb(v[0])+.7152*srgb(v[1])+.0722*srgb(v[2]);
 const contrast=(a,b)=>{const x=lum(Array.isArray(a)?a:rgb(a)),y=lum(Array.isArray(b)?b:rgb(b));return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
 const hsl=(r,g,b)=>{r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn,l=(mx+mn)/2;let h=0;
   if(d){if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;h=(h*60+360)%360}
   return {h,s:d===0?0:d/(1-Math.abs(2*l-1)),l};};
 const hash=s=>{let h=2166136261;for(let i=0;i<String(s).length;i++){h^=String(s).charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};
 function analyze(raw,w,h,key='unknown'){
   const data=raw.data||raw, width=w||raw.width||84, height=h||raw.height||84;
   const buckets=Array.from({length:24},(_,i)=>({index:i,score:0,r:0,g:0,b:0,n:0}));
   let total=0,sum=0,sum2=0,saturation=0,dark=0,bright=0,edge=0,edgeN=0;
   let coolWeight=0,warmWeight=0,neutral=[0,0,0], chroma=0;
   const step=2;
   for(let y=0;y<height;y+=step)for(let x=0;x<width;x+=step){
     const i=(y*width+x)*4;if(data[i+3]<180)continue;
     const r=data[i],g=data[i+1],b=data[i+2],v=(r*0.2126+g*.7152+b*.0722)/255;
     const hs=hsl(r,g,b), sat=hs.s;
     total++;sum+=v;sum2+=v*v;saturation+=sat;neutral[0]+=r;neutral[1]+=g;neutral[2]+=b;
     if(v<.25)dark++;if(v>.82)bright++;
     if(sat>.16 && hs.l>.07 && hs.l<.95){const bi=Math.floor(hs.h/15)%24,p=buckets[bi],wt=.55+sat*.75;
       p.score+=wt;p.r+=r*wt;p.g+=g*wt;p.b+=b*wt;p.n++;chroma++;
       if(hs.h>=165&&hs.h<=275)coolWeight+=wt; else if(hs.h<80||hs.h>=320)warmWeight+=wt;}
     if(x+2<width){const j=(y*width+x+2)*4;edge+=Math.abs(r-data[j])*.2126+Math.abs(g-data[j+1])*.7152+Math.abs(b-data[j+2])*.0722;edgeN++}
   }
   if(!total){return fallback('#918783',key)}
   const mean=sum/total,dev=Math.sqrt(Math.max(0,sum2/total-mean*mean));
   const avgSat=saturation/total, complexity=clamp((edge/Math.max(1,edgeN))/64,0,1);
   let sorted=buckets.filter(x=>x.score>0).sort((a,b)=>b.score-a.score), dominant=sorted[0];
   const isNight=dark/total>.51 && mean<.37;
   // Night skies: a tiny orange highlight must not override a significant cool field.
   if(isNight && coolWeight>warmWeight*.25){const cool=sorted.find(p=>p.index>=11&&p.index<=18&&p.score>Math.max(2,(sorted[0]?.score||0)*.10));if(cool)dominant=cool;}
   const avg=neutral.map(v=>v/total);
   const pigment=dominant?[dominant.r,dominant.g,dominant.b].map(v=>v/dominant.score):avg;
   const alt=sorted.find(p=>p!==dominant&&p.score>Math.max(2,(dominant?.score||1)*.18));
   const second=alt?[alt.r,alt.g,alt.b].map(v=>v/alt.score):mix(pigment,avg,.52);
   const variance=alt ? clamp(alt.score/(alt.score+(dominant?.score||1)),0,1):0;
   const monochrome=avgSat<.14||chroma/total<.11;
   const contrastiness=dev>.24;
   let identity;
   if(monochrome && bright/total>.42) identity='porcelain';
   else if(monochrome) identity='graphite';
   else if(isNight) identity='nocturne';
   else if(variance>.32 && complexity>.32) identity='prismatic';
   else if(mean>.69 && avgSat<.38) identity='gossamer';
   else if(complexity>.47 && contrastiness) identity='etched';
   else if(avgSat>.51 && mean>.45) identity='chromatic';
   else identity='atelier';
   const pigmentSoft=mix(pigment,[245,234,223],isNight?.25:.31);
   const paper=mix(pigment,[255,252,249],isNight?.90:.925);
   const ink=[38,34,36]; // Stable accessible ink for paper-backed typography.
   const accentBase=mix(pigment,[39,37,43],.25);
   let accent=accentBase;
   for(let t=0;contrast(accent,paper)<4.5&&t<12;t++) accent=mix(accent,[24,24,29],.14);
   const muted=mix(ink,paper,.43);
   const accentContrast=contrast(accent,paper);
   const appearance={
     identity,seed:hash(key),primary:hex(pigment),secondary:hex(second),ink:hex(ink),paper:hex(paper),
     accent:hex(accent),muted:hex(muted),resin:hex(pigmentSoft),
     contrast:Number(accentContrast.toFixed(2)),
     typography: complexity>.45?'editorial':monochrome?'quiet':isNight?'spacious':'balanced',
     reflection: isNight?'low':avgSat>.5?'luminous':'soft',
     stats:{brightness:Number(mean.toFixed(3)),saturation:Number(avgSat.toFixed(3)),complexity:Number(complexity.toFixed(3)),variance:Number(variance.toFixed(3)),dark:Number((dark/total).toFixed(3))}
   };
   return appearance;
 }
 function fallback(color,key='fallback'){
   const base=rgb(color),p=mix(base,[255,252,249],.94),accent=mix(base,[20,20,24],.68);
   return {identity:'atelier',seed:hash(key),primary:hex(base),secondary:hex(base),ink:'#262224',paper:hex(p),accent:hex(accent),muted:'#747071',resin:hex(mix(base,[245,234,223],.4)),contrast:Number(contrast(accent,p).toFixed(2)),typography:'balanced',reflection:'soft',stats:{brightness:0,saturation:0,complexity:0,variance:0,dark:0}};
 }
 let last=null;
 function apply(profile,key){
   const style=document.documentElement.style;
   const properties={'--cv-paper':profile.paper,'--cv-paper-light':hex(mix(rgb(profile.paper),[255,255,255],.65)),
     '--cv-paper-deep':hex(mix(rgb(profile.paper),rgb(profile.primary),.16)),
     '--cv-ink':profile.ink,'--cv-muted':profile.muted,'--cv-accent':profile.accent,
     '--cv-accent-dark':profile.accent,'--cv-disc':profile.resin,
     '--cv-disc-light':hex(mix(rgb(profile.resin),[255,255,255],.38)),
     '--cv-disc-deep':hex(mix(rgb(profile.resin),[72,61,66],.27)),
     '--cv-line':hex(mix(rgb(profile.primary),[255,255,255],.64)),
     '--vf-identity-ambient':profile.reflection==='luminous'?'.16':profile.reflection==='low'?'.07':'.11',
     '--vf-identity-spacing':profile.typography==='spacious'?'0.028em':profile.typography==='quiet'?'0.005em':'-0.02em'};
   for(const [k,v] of Object.entries(properties))style.setProperty(k,v);
   document.body.dataset.albumIdentity=profile.identity;
   document.body.dataset.albumTypography=profile.typography;
   document.querySelector('meta[name="theme-color"]')?.setAttribute('content',profile.paper);
   if(root.Vinyl?.setChromeColour)try{root.Vinyl.setChromeColour(profile.paper)}catch(_){}
   last={...profile,key};
   root.VFAlbumIdentity.last=last;
   root.dispatchEvent(new CustomEvent('vf:albumidentity',{detail:last}));
 }
 root.VFAlbumIdentity={analyze,fallback,apply,contrast,hash,last};
})(window);
