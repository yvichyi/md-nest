"""Browser functional and visual witnesses; never claims Android device or live NetEase."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw,ImageFilter
import io,base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
output=Path('/mnt/data/VinylField-0.14.5-pressing-tests');output.mkdir(exist_ok=True)

def make_cover(kind):
    im=Image.new('RGB',(360,360),(235,230,224));d=ImageDraw.Draw(im)
    if kind=='pearl':
        d.rectangle((0,0,360,360),fill=(242,238,230));d.ellipse((90,90,270,270),outline=(201,191,181),width=3);d.text((110,163),'THE AIR',fill=(89,85,81))
    elif kind=='smoke':
        d.rectangle((0,0,360,360),fill=(16,24,35));d.polygon([(30,330),(164,65),(330,330)],fill=(36,62,77));d.ellipse((210,38,252,80),fill=(195,105,91))
    elif kind=='duotone':
        d.rectangle((0,0,182,360),fill=(39,187,179));d.rectangle((182,0,360,360),fill=(208,46,135));d.arc((40,40,330,330),0,310,fill=(245,224,203),width=9)
    elif kind=='marble':
        d.rectangle((0,0,360,360),fill=(130,39,136));
        for i in range(12):d.ellipse((i*21,-60+i*10,i*21+170,300+i*14),outline=(255,177,50) if i%2 else (43,180,183),width=14)
    elif kind=='warm':
        d.rectangle((0,0,360,360),fill=(216,153,100));d.ellipse((40,70,290,320),fill=(110,70,53));d.ellipse((95,100,255,260),fill=(233,201,145))
    elif kind=='blue':
        d.rectangle((0,0,360,360),fill=(44,103,152));d.polygon([(0,290),(200,30),(359,190),(260,360)],fill=(94,176,215));d.ellipse((230,48,280,98),fill=(227,215,192))
    b=io.BytesIO();im.save(b,'PNG');return 'data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()

def bundled():
    s=(root/'index.html').read_text()
    for name in ['ui-bundle.css']:
        s=s.replace(f'<link rel="stylesheet" href="{name}" />','<style>'+ (root/name).read_text() +'</style>')
    for name in ('demo-coffee-cover.jpg','demo-orbit-cover.jpg'):
        b='data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode();s=s.replace(name,b)
    for name in ['playback-clock.js','pressing-studio.js','app.js']:
        s=s.replace(f'<script src="{name}"></script>','<script>'+(root/name).read_text()+'</script>')
    return s

def run():
  with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
    for width,height in [(1280,720),(850,393),(390,844)]:
      page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
      errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
      page.set_content(bundled(),wait_until='load',timeout=60000)
      page.wait_for_timeout(100)
      for kind in (['warm','blue','pearl','smoke','duotone','marble'] if width==1280 else ['warm','blue']):
        url=make_cover(kind)
        page.evaluate('''(arg)=>{window.VFPressingStudio.install(arg.url,arg.key,arg.hex)}''',{'url':url,'key':kind,'hex':'#99857f'})
        page.wait_for_function('(name)=>window.VFPressingStudio.last?.key === name',arg=kind,timeout=10000)
        meta=page.evaluate('window.VFPressingStudio.last')
        assert meta['key']==kind and meta['pigments'][0]!=meta['pigments'][1]
        assert not errors,(kind,errors)
        if width==1280:page.screenshot(path=str(output/f'pressing-{kind}.png'))
        elif kind=='blue':page.screenshot(path=str(output/f'pressing-{kind}-{width}x{height}.png'))
        assert not page.evaluate('document.documentElement.scrollWidth>innerWidth+2'),(kind,width,height)
        if width==1280:print('PRESS',kind,meta['finish'],meta['pigments'])
      # Determinism check: redraw using same image; digest must remain unchanged.
      url=make_cover('duotone');page.evaluate('url=>window.VFPressingStudio.install(url,"duotone","#99857f")',url)
      page.wait_for_function('window.VFPressingStudio.last?.key==="duotone"')
      first=page.evaluate('document.getElementById("vinyl").style.getPropertyValue("--vf-pressing-image")')
      page.evaluate('url=>window.VFPressingStudio.install(url,"duotone","#99857f")',url)
      page.wait_for_timeout(120)
      second=page.evaluate('document.getElementById("vinyl").style.getPropertyValue("--vf-pressing-image")')
      assert first==second
      # Real interaction regressions: folio and queue both accessible; preserve scroll.
      page.click('#focusToggle');assert 'lyrics-focus' in page.locator('#stage').get_attribute('class')
      assert not page.locator('.deck-frame').is_visible()
      page.click('#focusToggle')
      page.click('#toolsToggle',timeout=4000);page.click('#queueBtn',timeout=4000);assert page.locator('#queueOverlay').get_attribute('aria-hidden')=='false'
      print('VIEW',width,height,'pressings=6; folio & queue accessible; JS errors=0')
      page.close()
    browser.close()
if __name__=='__main__':run()
