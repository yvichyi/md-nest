from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
def bundled(kind=None,native=False):
    html=(root/'index.html').read_text()
    for name in ['style.css','cover-theme.css','immersive-motion.css','art-direction.css','motion-engine.css']:
        html=html.replace(f'<link rel="stylesheet" href="{name}" />', '<style>'+ (root/name).read_text() +'</style>')
    for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
        html=html.replace(name,'data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode())
    clock=(root/'playback-clock.js').read_text()
    js=(root/'app.js').read_text()
    for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
        js=js.replace(name,'data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode())
    if kind:
        js=js.replace("const visualDemo = !native && new URLSearchParams(location.search).get('demo');",f"const visualDemo = '{kind}';")
    native_js='''window.Vinyl={setChromeColour(){},playLocalQueue(...args){window.__nativeQueue=args;},play(){},setQueueMode(){},playQueueIndex(){},next(){},previous(){},seek(){},pause(){},resume(){},pickAudio(){},landscape(){},portrait(){}};''' if native else ''
    html=html.replace('<script src="playback-clock.js"></script>','').replace('<script src="app.js"></script>',f'<script>{native_js}\n{clock}\n{js}</script>')
    return html

fixture=Path('/mnt/data/VinylField-0.6.0-audio-fixture.wav')
assert fixture.exists()
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
  page=browser.new_page(viewport={'width':1280,'height':720})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(bundled(),wait_until='load')
  page.locator('#browserFile').set_input_files(str(fixture))
  page.wait_for_timeout(600)
  one=page.evaluate('window.VF.motionSnapshot()')
  assert one['position']>30 and one['velocity']>1,one
  page.locator('#playBtn').click()
  page.wait_for_timeout(500)
  two=page.evaluate('window.VF.motionSnapshot()')
  assert two['velocity']<one['velocity'],(one,two)
  page.wait_for_timeout(300)
  three=page.evaluate('window.VF.motionSnapshot()')
  assert abs(two['position']-three['position'])<45,(two,three)
  assert not errors,errors
  print('PASS real local WAV → playback position and rotation → pause inertia and frozen time',one,two,three)
  browser.close()
