from pathlib import Path
import importlib.util
ns={'__file__':str(Path(__file__).resolve().parent/'test_queue_100.py')}
code=(Path(__file__).resolve().parent/'test_queue_100.py').read_text().split('with sync_playwright() as pw:')[0]
exec(code,ns)
bundle=ns['bundle']
from playwright.sync_api import sync_playwright
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(1280,720),(850,393),(390,844)]:
  p=b.new_page(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,device_scale_factor=1)
  p.set_content(bundle());p.evaluate('window.__vfQA.seedQueue(100);window.__vfQA.open()');p.wait_for_timeout(560)
  p.evaluate('document.querySelector("#queueResults").scrollTo({top:0,behavior:"instant"})')
  rect=p.locator('#queueResults').bounding_box()
  x=rect['x']+rect['width']*.60;y=rect['y']+rect['height']*.78
  before=p.evaluate('document.querySelector("#queueResults").scrollTop')
  cdp=p.context.new_cdp_session(p)
  cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
  for j in range(1,10):
   cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x,'y':y-j*22}]})
   p.wait_for_timeout(18)
  cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
  p.wait_for_timeout(360)
  after=p.evaluate('document.querySelector("#queueResults").scrollTop')
  print('TOUCH',w,h,'before',before,'after',after)
  assert after>before+40,(w,h,before,after)
  p.close()
 b.close()
