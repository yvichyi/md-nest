from pathlib import Path
from playwright.sync_api import sync_playwright
import base64, json, time
root=Path(__file__).resolve().parents[1]/'app/src/main/assets';out=Path('/mnt/data')
def bundle(kind='warm'):
 h=(root/'index.html').read_text()
 for name in ['ui-bundle.css']:
  h=h.replace(f'<link rel="stylesheet" href="{name}" />','<style>'+ (root/name).read_text()+'</style>')
 js=(root/'app.js').read_text()
 clock=(root/'playback-clock.js').read_text()
 for name in ['demo-coffee-cover.jpg','demo-orbit-cover.jpg']:
  data='data:image/jpeg;base64,'+base64.b64encode((root/name).read_bytes()).decode()
  h=h.replace(name,data);js=js.replace(name,data)
 js=js.replace("const visualDemo = !native && new URLSearchParams(location.search).get('demo');",f"const visualDemo = '{kind}';")
 h=h.replace('<script src="playback-clock.js"></script>','').replace('<script src="pressing-studio.js"></script>','').replace('<script src="app.js"></script>',f'<script>{clock}\n{(root/"pressing-studio.js").read_text()}\n{js}</script>')
 return h
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
 for w,h,k in [(1280,720,'warm'),(1280,720,'blue'),(850,393,'warm'),(390,844,'warm')]:
  page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(bundle(k),wait_until='load');page.wait_for_timeout(250)
  assert page.locator('#recordCover').is_visible(),f'no artwork {w}'
  assert page.evaluate('document.documentElement.scrollWidth <= innerWidth+2'), f'overflow {w}'
  page.screenshot(path=str(out/f'VinylField-0.12.0-{k}-{w}x{h}.png'))
  page.locator('#focusToggle').click();page.wait_for_timeout(520)
  vis=page.evaluate('''()=>({mode:document.querySelector('#stage').classList.contains('lyrics-focus'),deck:getComputedStyle(document.querySelector('.deck-column')).visibility,folio:document.querySelector('.folio-credit').getBoundingClientRect().width,focusImg:!document.querySelector('#folioCover').hidden,focusText:document.querySelector('#focusToggle').innerText,toast:document.querySelector('#toast').classList.contains('show'),scrollWidth:document.documentElement.scrollWidth})''')
  print('FOLIO',w,h,k,json.dumps(vis,ensure_ascii=False))
  assert vis['mode'] and vis['deck']=='hidden' and vis['focusImg'] and vis['scrollWidth']<=w+2,vis
  assert not vis['toast'], 'mode-change toast should not appear'
  page.screenshot(path=str(out/f'VinylField-0.12.0-folio-{w}x{h}.png'))
  page.locator('#focusToggle').click();page.wait_for_timeout(120)
  assert page.locator('#stage').get_attribute('class').find('lyrics-focus')<0
  # Build 100 real result rows using normal app row generator by opening queue
  page.evaluate('''()=>{
   const root=document.querySelector('#queueResults');
   for(let i=0;i<100;i++){
    const row=document.createElement('div');row.className='result';row.dataset.queueIndex=i;
    row.innerHTML='<div class="result-art">♪</div><div class="result-copy"><strong>测试曲目 '+(i+1)+'</strong><span>Artist</span></div><span class="result-end">'+i+'</span>';
    root.appendChild(row);
   }
   document.querySelector('#queueOverlay').classList.add('open');
   document.querySelector('#queueOverlay').setAttribute('aria-hidden','false');
  }''')
  page.wait_for_timeout(130)
  # synthetic DOM rows for scrolling rather than simulated native queue: focuses on scroll reachability.
  scroll=page.evaluate('''()=>{let e=document.querySelector('#queueResults');return {client:e.clientHeight,scroll:e.scrollHeight,overflow:getComputedStyle(e).overflowY,outer:getComputedStyle(document.querySelector('#queueOverlay .library-panel')).overflow};}''')
  assert scroll['scroll']>scroll['client'] and scroll['overflow']=='auto',scroll
  page.evaluate("document.querySelector('#queueResults').scrollTo({top:document.querySelector('#queueResults').scrollHeight,behavior:'instant'})")
  page.wait_for_timeout(90)
  bottom=page.evaluate('''()=>{let e=document.querySelector('#queueResults');return {atBottom:e.scrollTop+e.clientHeight>=e.scrollHeight-3,last:e.lastElementChild.getBoundingClientRect().bottom<=e.getBoundingClientRect().bottom+2}}''')
  assert bottom['atBottom'] and bottom['last'], (scroll,bottom)
  print('QUEUE',w,h,scroll,bottom,'ERRORS',errors)
  assert not errors,errors
  page.screenshot(path=str(out/f'VinylField-0.12.0-queue-{w}x{h}.png'))
  page.close()
 browser.close()
